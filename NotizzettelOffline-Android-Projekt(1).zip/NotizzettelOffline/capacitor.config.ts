import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = { appId: 'de.notizzettel.offline', appName: 'Mein Notizzettel', webDir: 'dist' };
export default config;
