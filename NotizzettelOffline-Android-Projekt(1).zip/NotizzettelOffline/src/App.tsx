import React, { useEffect, useMemo, useState } from "react";
import { Check, Eraser, Flame, Plus, Sparkles, Trash2, X } from "lucide-react";

type Todo = { id: string; text: string; createdAt: string; done: boolean };
type Filter = "alle" | "offen" | "erledigt";
type Result = { saved: number; remaining: number; error: string | null; reloadError: string | null } | null;

const COLLECTION = "todos";
const DAY = 86_400_000;

async function api(action: string, args: Record<string, unknown>) {
  const key = "notizzettel-todos-v1";
  const rows: Todo[] = JSON.parse(localStorage.getItem(key) || "[]");
  if (action === "records.list") return { records: rows.map((value) => ({ id: value.id, value })) };
  if (action === "records.create") {
    const value = args.value as Todo;
    rows.push({ ...value, id: String(args.idempotency_key || stableKey("todo")) });
  } else if (action === "records.replace") {
    const i = rows.findIndex((r) => r.id === args.id);
    if (i >= 0) rows[i] = args.value as Todo;
  } else if (action === "records.delete") {
    const next = rows.filter((r) => r.id !== args.id);
    localStorage.setItem(key, JSON.stringify(next));
    return { ok: true };
  }
  localStorage.setItem(key, JSON.stringify(rows));
  return { ok: true };
}

function todayInput() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function ageDays(iso: string) {
  return Math.max(0, Math.floor((Date.now() - new Date(iso).getTime()) / DAY));
}
function hexToRgb(hex: string) {
  return [parseInt(hex.slice(1, 3), 16), parseInt(hex.slice(3, 5), 16), parseInt(hex.slice(5, 7), 16)];
}
function ageColor(days: number) {
  const t = Math.min(days / 30, 1);
  const a = hexToRgb("#FFF59D"), b = hexToRgb("#8B0000");
  const mix = a.map((v, i) => Math.round(v + (b[i] - v) * t));
  const bg = `rgb(${mix.join(",")})`;
  const luminance = (0.299 * mix[0] + 0.587 * mix[1] + 0.114 * mix[2]) / 255;
  return { bg, dark: luminance < 0.52, progress: t };
}
function ageLabel(days: number) {
  if (days === 0) return "heute";
  if (days === 1) return "vor 1 Tag";
  if (days < 30) return `vor ${days} Tagen`;
  const months = Math.floor(days / 30);
  return months === 1 ? "vor ca. 1 Monat" : `vor ca. ${months} Monaten`;
}
function formatDate(iso: string) {
  return new Intl.DateTimeFormat("de-DE", { day: "2-digit", month: "2-digit", year: "numeric" }).format(new Date(iso));
}
function stableKey(prefix: string) {
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
}

export default function App() {
  const [todos, setTodos] = useState<Todo[]>([]);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const [text, setText] = useState("");
  const [date, setDate] = useState(todayInput());
  const [filter, setFilter] = useState<Filter>("alle");
  const [busy, setBusy] = useState(false);
  const [result, setResult] = useState<Result>(null);
  const [formError, setFormError] = useState<string | null>(null);

  async function reloadRecords() {
    const data = await api("records.list", { collection: COLLECTION });
    const rows = (data?.records || []).map((r: { id: string; value: Todo }) => ({ ...r.value, id: r.id }));
    rows.sort((a: Todo, b: Todo) => Number(a.done) - Number(b.done) || new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime());
    setTodos(rows);
  }

  useEffect(() => {
    reloadRecords().catch((e) => setLoadError(e instanceof Error ? e.message : String(e))).finally(() => setLoading(false));
  }, []);

  async function createRow(row: Omit<Todo, "id">) {
    await api("records.create", { collection: COLLECTION, value: row, idempotency_key: stableKey("todo") });
  }

  async function addTodo(e?: React.FormEvent) {
    e?.preventDefault();
    const clean = text.trim();
    if (!clean) { setFormError("Schreibe zuerst eine Aufgabe auf den Zettel."); return; }
    const chosen = date ? new Date(`${date}T12:00:00`) : new Date();
    if (Number.isNaN(chosen.getTime())) { setFormError("Bitte wähle ein gültiges Datum."); return; }
    setBusy(true); setFormError(null); setResult(null);
    try {
      await createRow({ text: clean, createdAt: chosen.toISOString(), done: false });
      await reloadRecords();
      setText(""); setDate(todayInput());
      setResult({ saved: 1, remaining: 0, error: null, reloadError: null });
    } catch (err) {
      setResult({ saved: 0, remaining: 1, error: err instanceof Error ? err.message : String(err), reloadError: null });
    } finally { setBusy(false); }
  }

  async function addExamples() {
    const rows: Omit<Todo, "id">[] = [
      { text: "Beispiel: Frische Aufgabe — heute aufgeschrieben", createdAt: new Date().toISOString(), done: false },
      { text: "Beispiel: Schon 45 Tage auf dem Zettel", createdAt: new Date(Date.now() - 45 * DAY).toISOString(), done: false },
      { text: "Beispiel: Über 95 Tage alt — bitte dringend erledigen", createdAt: new Date(Date.now() - 95 * DAY).toISOString(), done: false },
    ];
    setBusy(true); setResult(null);
    let saved = 0; let error: string | null = null;
    try { for (const row of rows) { await createRow(row); saved += 1; } }
    catch (e) { error = e instanceof Error ? e.message : String(e); }
    let reloadError: string | null = null;
    try { await reloadRecords(); } catch (e) { reloadError = e instanceof Error ? e.message : String(e); }
    setResult({ saved, remaining: rows.length - saved, error, reloadError });
    setBusy(false);
  }

  async function toggleTodo(todo: Todo) {
    setBusy(true);
    try { await api("records.replace", { collection: COLLECTION, id: todo.id, value: { ...todo, done: !todo.done } }); await reloadRecords(); }
    catch (e) { setResult({ saved: 0, remaining: 1, error: e instanceof Error ? e.message : String(e), reloadError: null }); }
    finally { setBusy(false); }
  }

  async function deleteTodo(id: string) {
    setBusy(true);
    try { await api("records.delete", { collection: COLLECTION, id }); await reloadRecords(); }
    catch (e) { setResult({ saved: 0, remaining: 1, error: e instanceof Error ? e.message : String(e), reloadError: null }); }
    finally { setBusy(false); }
  }

  async function clearDone() {
    const done = todos.filter((t) => t.done);
    setBusy(true); setResult(null);
    let saved = 0; let error: string | null = null;
    try { for (const row of done) { await api("records.delete", { collection: COLLECTION, id: row.id }); saved += 1; } }
    catch (e) { error = e instanceof Error ? e.message : String(e); }
    let reloadError: string | null = null;
    try { await reloadRecords(); } catch (e) { reloadError = e instanceof Error ? e.message : String(e); }
    setResult({ saved, remaining: done.length - saved, error, reloadError });
    setBusy(false);
  }

  const visible = useMemo(() => todos.filter((t) => filter === "alle" || (filter === "offen" ? !t.done : t.done)), [todos, filter]);
  const openCount = todos.filter((t) => !t.done).length;
  const doneCount = todos.length - openCount;

  return (
    <div data-safe-area-inset-root style={{ boxSizing: "border-box", paddingTop: "var(--safe-area-inset-top)", minHeight: "100vh", overflowX: "clip" }}>
      <main className="mx-auto w-full max-w-[560px] px-3 pb-10 pt-6 sm:px-5 sm:pt-10">
        <header className="mb-2 text-center text-white drop-shadow-[0_2px_2px_rgba(0,0,0,.45)]">
          <p className="text-sm tracking-[.22em] uppercase opacity-90">Dein Schreibtisch · Notizzettel</p>
          <h1 className="hand mt-1 text-[clamp(2.2rem,8vw,3.4rem)] leading-none font-bold">Kleine Zettel, große Wirkung</h1>
          <p className="mx-auto mt-2 max-w-md text-base leading-snug opacity-95">Je länger eine Aufgabe hier klebt, desto dunkler wird sie — von Gelb bis Dunkelrot. Nach 30 Tagen fängt sie an zu brennen.</p>
        </header>

        <section aria-label="Top To-Do Liste" className="relative mt-8 rotate-[-.45deg]">
          <div className="tape absolute -top-4 left-1/2 z-20 h-9 w-36 -translate-x-1/2 -rotate-3 rounded-[2px]" aria-hidden="true" />
          <div className="paper relative z-10 px-3 pb-5 pt-10 sm:px-5">
            <div className="pointer-events-none absolute bottom-0 left-9 top-12 w-px bg-red-400/70" aria-hidden="true" />
            <div className="pl-5 sm:pl-7">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <p className="text-xs uppercase tracking-[.2em] text-stone-500">Nicht vergessen:</p>
                  <h2 className="hand text-[clamp(2.1rem,8vw,3.1rem)] leading-[.9] text-stone-900">Meine Top To-Do Liste</h2>
                </div>
                <span className="mt-2 hidden shrink-0 rotate-3 rounded-full border border-red-900/25 bg-red-50 px-2 py-1 text-[11px] font-bold text-red-900 sm:block">30 Tage<br />bis Dunkelrot</span>
              </div>

              <form onSubmit={addTodo} className="mt-6">
                <label htmlFor="task" className="text-base font-bold text-stone-800">Neue Aufgabe</label>
                <div className="mt-2 flex flex-col gap-2">
                  <input id="task" value={text} onChange={(e) => setText(e.target.value)} maxLength={140} placeholder="Was steht heute an?" className="w-full rounded-lg border-2 border-stone-800/80 bg-white/80 px-3 py-3 text-lg text-stone-900 shadow-sm outline-none placeholder:text-stone-400 focus:border-red-800" />
                  <div className="flex flex-col gap-2 sm:flex-row">
                    <label className="flex flex-1 items-center gap-2 rounded-lg border border-stone-400 bg-white/70 px-3 py-2 text-sm text-stone-700">
                      <span className="shrink-0">Datum (optional)</span>
                      <input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="min-w-0 flex-1 bg-transparent outline-none" />
                    </label>
                    <button type="submit" disabled={busy} className="flex items-center justify-center gap-2 rounded-lg bg-[#9d2f1e] px-4 py-3 font-bold text-white shadow-md hover:bg-[#7e2417] focus:outline-none focus:ring-2 focus:ring-red-900 focus:ring-offset-2">
                      <Plus size={19} /> Hinzufügen
                    </button>
                  </div>
                </div>
                {formError && <p role="alert" className="mt-2 text-sm font-bold text-red-800">{formError}</p>}
                <p className="mt-2 text-sm leading-snug text-stone-500">Tipp: Mit einem älteren Datum kannst du den Farbwechsel sofort testen.</p>
              </form>

              <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-y border-stone-300/70 py-3">
                <div className="flex flex-wrap gap-1" role="group" aria-label="Aufgaben filtern">
                  {([["alle", `Alle (${todos.length})`], ["offen", `Offen (${openCount})`], ["erledigt", `Erledigt (${doneCount})`]] as [Filter, string][]).map(([value, label]) => (
                    <button key={value} onClick={() => setFilter(value)} aria-pressed={filter === value} className={`rounded-full px-3 py-1.5 text-sm font-bold ${filter === value ? "bg-stone-900 text-white" : "bg-white/70 text-stone-700 hover:bg-white"}`}>{label}</button>
                  ))}
                </div>
                <button onClick={clearDone} disabled={busy || doneCount === 0} className="flex items-center gap-1.5 text-sm font-bold text-red-800 hover:underline disabled:no-underline disabled:opacity-40"><Eraser size={16} /> Erledigte löschen</button>
              </div>

              <div className="mt-3 min-h-[280px]">
                {loading ? <p className="py-10 text-center text-stone-500">Dein Zettel wird geladen …</p> : loadError ? <p role="alert" className="rounded-lg bg-red-50 px-3 py-3 text-sm text-red-900">Der Zettel konnte nicht geladen werden: {loadError}</p> : visible.length === 0 ? (
                  <div className="py-8 text-center">
                    <p className="hand text-3xl text-stone-700">{filter === "alle" ? "Noch ganz leer — leg los!" : filter === "offen" ? "Nichts offen. Sehr gut!" : "Noch nichts erledigt."}</p>
                    <p className="mx-auto mt-1 max-w-xs text-sm text-stone-500">Schreibe oben deine erste Aufgabe auf. Oder lass dir zeigen, wie die Farben mit dem Alter wachsen.</p>
                    {filter === "alle" && <button onClick={addExamples} disabled={busy} className="mt-4 inline-flex items-center gap-2 rounded-full border-2 border-stone-800 bg-amber-100 px-4 py-2 font-bold text-stone-900 hover:bg-amber-200"><Sparkles size={17} /> 3 Beispiel-Aufgaben einfügen</button>}
                  </div>
                ) : (
                  <ul className="space-y-3">
                    {visible.map((todo) => {
                      const days = ageDays(todo.createdAt);
                      const color = ageColor(days);
                      const burning = days >= 30;
                      const preBurn = days >= 25 && days < 30 && !todo.done;
                      const ink = color.dark ? "text-white" : "text-stone-900";
                      const sub = color.dark ? "text-white/80" : "text-stone-600";
                      return (
                        <li key={todo.id} className={`task-row relative rounded-md p-2.5 shadow-[0_1px_2px_rgba(0,0,0,.18)] ${burning ? "burning-row pb-6" : preBurn ? "pre-burn-row" : ""}`} style={{ backgroundColor: color.bg }}>
                          {burning && (
                            <>
                              <span className="burn-spots" aria-hidden="true" />
                              <span className="smoke-layer" aria-hidden="true"><i className="smoke s1" /><i className="smoke s2" /><i className="smoke s3" /></span>
                              <span className="flame-layer" aria-hidden="true"><i className="flame f1" /><i className="flame f2" /><i className="flame f3" /><i className="flame f4" /><i className="flame f5" /></span>
                              <span className="spark-layer" aria-hidden="true"><i className="spark sp1" /><i className="spark sp2" /><i className="spark sp3" /><i className="spark sp4" /></span>
                            </>
                          )}
                          {preBurn && (
                            <span className="ember-layer" aria-hidden="true"><i className="ember e1" /><i className="ember e2" /><i className="ember e3" /><i className="smoke smoke-small s1" /></span>
                          )}
                          <div className="relative flex items-start gap-2.5">
                            <button onClick={() => toggleTodo(todo)} disabled={busy} aria-label={`${todo.done ? "Als offen markieren" : "Als erledigt markieren"}: ${todo.text}`} className={`mt-0.5 grid h-7 w-7 shrink-0 place-items-center rounded-md border-2 ${color.dark ? "border-white bg-white/15 text-white" : "border-stone-800 bg-white/70 text-stone-900"}`}>
                              {todo.done && <Check size={18} strokeWidth={3.5} />}
                            </button>
                            <div className="min-w-0 flex-1">
                              {burning && (
                                <span className="burn-badge"><Flame size={14} strokeWidth={2.5} aria-hidden="true" /> BRENNT! · über 30 Tage alt</span>
                              )}
                              {preBurn && (
                                <span className="pre-burn-badge"><Flame size={13} strokeWidth={2.5} aria-hidden="true" /> Fängt bald an zu brennen!</span>
                              )}
                              <p className={`break-words text-[1.05rem] leading-tight ${ink} ${todo.done ? "line-through opacity-70" : ""} ${burning ? "burnt-text" : ""}`}>
                                {burning && <Flame size={18} strokeWidth={2.5} aria-hidden="true" className="mr-1 inline-block -translate-y-px align-middle text-orange-300" />}
                                {todo.text}
                              </p>
                              <p className={`mt-1 text-xs ${sub}`}>{formatDate(todo.createdAt)} · {ageLabel(days)} {days >= 30 && !todo.done ? "· dringend!" : ""}</p>
                              <div className="mt-2 flex items-center gap-2">
                                <div className="h-1.5 flex-1 overflow-hidden rounded-full bg-black/15" aria-label={`${Math.round(color.progress * 100)} Prozent der 90 Tage vergangen`}>
                                  <div className="h-full rounded-full bg-black/35" style={{ width: `${Math.round(color.progress * 100)}%` }} />
                                </div>
                                <span className={`shrink-0 text-[11px] font-bold ${sub}`}>{days}/30 Tage</span>
                              </div>
                            </div>
                            <button onClick={() => deleteTodo(todo.id)} disabled={busy} aria-label={`Aufgabe löschen: ${todo.text}`} className={`grid h-8 w-8 shrink-0 place-items-center rounded-full ${color.dark ? "text-white hover:bg-white/20" : "text-stone-700 hover:bg-black/10"}`}><X size={18} /></button>
                          </div>
                        </li>
                      );
                    })}
                  </ul>
                )}
              </div>

              <div className="mt-5 rounded-xl bg-white/70 p-3 shadow-inner">
                <p className="text-sm font-bold text-stone-800">Wie alt ist die Aufgabe?</p>
                <div className="mt-2 h-3 overflow-hidden rounded-full" style={{ background: "linear-gradient(90deg,#FFF59D,#FFB84D 33%,#E2632E 66%,#8B0000)" }} aria-hidden="true" />
                <div className="mt-2 grid grid-cols-2 gap-2 text-center text-[11px] leading-tight font-bold text-stone-600 sm:grid-cols-4">
                  <span><span className="mx-auto mb-1 block h-3 w-3 rounded-full bg-[#FFF59D] ring-1 ring-stone-300" />Gelb = neu</span>
                  <span><span className="mx-auto mb-1 block h-3 w-3 rounded-full bg-[#FF9B35]" />Orange = ca. 1–3 Wochen</span>
                  <span><span className="mx-auto mb-1 flex h-3 w-3 items-center justify-center rounded-full bg-[#ff6a00] ring-1 ring-black/30"><Flame size={9} className="text-white" /></span>Glut / Rauch = ab 25 Tagen</span>
                  <span><span className="mx-auto mb-1 flex h-3 w-3 items-center justify-center rounded-full bg-[#8B0000]"><Flame size={9} className="text-orange-300" /></span>Dunkelrot + Flammen = 30+ Tage, BRENNT!</span>
                </div>
              </div>

              {result && (
                <div role="status" className="mt-4 rounded-lg bg-white/80 px-3 py-2 text-sm text-stone-800">
                  Gespeichert: {result.saved} · Verbleibend: {result.remaining}
                  {result.error && <span className="mt-1 block font-bold text-red-800">Hinweis: {result.error}</span>}
                  {result.reloadError && <span className="mt-1 block font-bold text-red-800">Aktualisieren fehlgeschlagen: {result.reloadError}</span>}
                </div>
              )}
              <p className="mt-4 flex items-center justify-center gap-1.5 text-center text-xs text-stone-500"><Trash2 size={13} /> Erledigte Aufgaben bleiben durchgestrichen, bis du sie löschst.</p>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
