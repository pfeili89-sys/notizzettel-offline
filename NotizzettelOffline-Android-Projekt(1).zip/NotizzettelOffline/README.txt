MEIN NOTIZZETTEL – OFFLINE ANDROID APP

Diese Version speichert Aufgaben lokal auf dem Gerät (localStorage), benötigt nach der Installation kein Internet und startet die Flammen ab 30 Tagen.

APK ohne PC bauen:
1. ZIP auf dem Android-Handy herunterladen.
2. Bei GitHub anmelden/registrieren und ein neues Repository erstellen.
3. ZIP entpacken und alle enthaltenen Dateien in das Repository hochladen (einschließlich .github-Ordner; falls verborgen, diesen Ordner separat über GitHub-Datei-Upload anlegen).
4. Im Repository auf Actions gehen.
5. Workflow „Android APK bauen“ auswählen und „Run workflow“ drücken.
6. Nach Abschluss den Lauf öffnen, unter Artifacts „Notizzettel-APK“ herunterladen und ZIP entpacken.
7. app-debug.apk antippen und Android die Installation aus dieser Quelle erlauben.

Hinweis: Der erste Build benötigt Internet bei GitHub. Die fertige App selbst funktioniert offline. Aufgaben bleiben lokal auf dem Handy; beim Deinstallieren oder Löschen der App-Daten können sie verloren gehen.
